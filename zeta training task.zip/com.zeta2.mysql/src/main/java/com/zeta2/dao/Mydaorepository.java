package com.zeta2.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zeta2.model.Loan;

//Interface extending JpaRepository for Loan entity with Integer as the type of the primary key
public interface Mydaorepository extends JpaRepository<Loan, Integer> {

}
