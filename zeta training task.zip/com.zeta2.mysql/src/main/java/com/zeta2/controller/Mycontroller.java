package com.zeta2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta2.LoanDetail;
import com.zeta2.model.Loan;
import com.zeta2.service.Myservice;
import org.apache.log4j.Logger;

//Controller class responsible for handling HTTP requests related to Loan entities
@RestController
public class Mycontroller {
	// Initializing a Logger instance for logging purposes
	static Logger lg = Logger.getLogger(LoanDetail.class);

	@Autowired
	Myservice service;

	@RequestMapping("/loan/all")
	// Handling GET request to retrieve all loans
	public List<Loan> getLoan() {
		return service.getLoans();
	}

	// Handling GET request to retrieve a loan by its ID
	@RequestMapping(value = "/loan/{loan_no}", method = RequestMethod.GET)
	public Loan getLoanById(@PathVariable int loan_no) throws Exception {
		lg.info(this.getClass().getSimpleName() + " - Get loyee details by id is invoked.");
		Loan ln = service.getLoanById(loan_no);
		return ln;
	}

	// Handling POST request to add a new loan
	@RequestMapping(value = "/loan/add", method = RequestMethod.POST)
	public Loan createLoan(@RequestBody Loan newln) {
		lg.info(this.getClass().getSimpleName() + " - Create new loyee method is invoked.");
		return service.addNewLoan(newln);
	}

	// Handling PUT request to update a loan by its ID
	@RequestMapping(value = "/loan/update/{loan_no}", method = RequestMethod.PUT)
	public Loan updateLoan(@RequestBody Loan upd, @PathVariable int loan_no) throws Exception {
		lg.info(this.getClass().getSimpleName() + " - Update loyee details by id is invoked.");
		Loan ln = service.getLoanById(loan_no);
		// Required for the "where" clause in the sql query tlate.
		// upd.setId(Loan_No);
		return service.updateLoan(upd);
	}

	// Handling DELETE request to delete a loan by its ID
	@RequestMapping(value = "/loan/delete/{loan_no}", method = RequestMethod.DELETE)
	public void deleteLoanById(@PathVariable int loan_no) throws Exception {
		lg.info(this.getClass().getSimpleName() + " - Delete loyee by id is invoked.");
		Loan ln = service.getLoanById(loan_no);
		service.deleteLoanById(loan_no);
	}
	// Handling DELETE request to delete all loans

	@RequestMapping(value = "/loan/deleteall", method = RequestMethod.DELETE)
	public void deleteAll() {
		lg.info(this.getClass().getSimpleName() + " - Delete all loyees is invoked.");
		service.deleteAllLoans();
	}

}
