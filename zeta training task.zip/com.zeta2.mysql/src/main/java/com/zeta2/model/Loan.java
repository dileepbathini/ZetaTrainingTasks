package com.zeta2.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//Entity class representing the "loan1" table in the database
@Entity
@Table(name = "loan1")
public class Loan {
	// Primary key field annotated with @Id
	@Id
	@Column
	private int loan_no;
	// Fields representing columns in the "loan1" table
	@Column
	private String aadhar;
	@Column
	private String cust_name;
	@Column
	private String last_name;
	@Column
	private int loan_amt;
	@Column
	private String start_date;
	@Column
	private int tenure;

	// Getter and Setter methods for each field
	public int getLoan_no() {
		return loan_no;
	}

	public void setLoan_no(int loan_no) {
		this.loan_no = loan_no;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public int getLoan_amt() {
		return loan_amt;
	}

	public void setLoan_amt(int loan_amt) {
		this.loan_amt = loan_amt;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

}
