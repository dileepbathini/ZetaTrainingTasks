package com.zeta2;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

//Annotation declaring this class as a Spring Boot application with Swagger 2 documentation support
@SpringBootApplication
@EnableSwagger2
public class LoanDetail {
	// Initializing a Logger instance for logging purposes
	static Logger lg = Logger.getLogger(LoanDetail.class);

	// Launching the Spring Boot application
	public static void main(String[] args) {
		SpringApplication.run(LoanDetail.class, args);
	}
}
