package com.zeta2.service;

import java.util.List;
import java.util.Optional;

import com.zeta2.model.Loan;

//Service interface defining methods for Loan-related operations
public interface Myservice {
	// Method to retrieve all loans
	public List<Loan> getLoans();

	// Method to retrieve a loan by its ID
	public Loan getLoanById(int Loan_No);

	// Method to add a new loan
	public Loan addNewLoan(Loan ln);

	// Method to update an existing loan
	public Loan updateLoan(Loan ln);

	// Method to delete a loan by its ID
	public void deleteLoanById(int Loan_No);

	// Method to delete all loans
	public void deleteAllLoans();

}
