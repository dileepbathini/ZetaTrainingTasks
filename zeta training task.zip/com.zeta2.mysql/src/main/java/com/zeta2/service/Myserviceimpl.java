package com.zeta2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta2.service.Myservice;
import com.zeta2.dao.Mydaorepository;
import com.zeta2.model.Loan;

@Service
public class Myserviceimpl implements Myservice {
	// Autowiring Mydaorepository for database operations
	@Autowired
	Mydaorepository dao;

	public List<Loan> getLoans() {
		return dao.findAll();
	}

	public Loan getLoanById(int loan_no) {
		return dao.findOne(loan_no);
	}

	public Loan addNewLoan(Loan ln) {
		return dao.save(ln);
	}

	public Loan updateLoan(Loan ln) {
		return dao.save(ln);
	}

	public void deleteLoanById(int loan_no) {
		dao.delete(loan_no);

	}

	public void deleteAllLoans() {
		dao.deleteAll();

	}

}
