package com.zeta2.mysql;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Date;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.test.context.junit4.SpringRunner;

import com.zeta2.dao.Mydaorepository;
import com.zeta2.model.Loan;

@RunWith(SpringRunner.class)
@SpringBootTest
//@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@FixMethodOrder()
public class JUnitTest {
@Autowired
private Mydaorepository repo;

@Test
@Order(1)
public void getLoanDetailsTest() {
List<Loan> list = repo.findAll();
assertEquals(3,list.size());
}

@Test
@Order(2)
public void addNewLoanTest(){
Loan l = new Loan();
l.setLoan_no(100);l.setAadhar("123456789876");
l.setCust_name("dileep");l.setLast_name("b");
l.setLoan_amt(2344);l.setStart_date("2027-10-17");l.setTenure(7);
repo.save(l);
assertNotNull(repo.findOne(100));
}

@Test
@Order(3)
public void getLoanByIdTest(){
Loan l = repo.findOne(11111);
assertEquals(4,l.getTenure(),0.0);
}

@Test
@Order(4)
public void updateLoanTest(){
Loan l = repo.findOne(11111);
l.setLoan_amt(2222);
repo.save(l);
assertNotEquals(82000,l.getLoan_amt());
}

@Test
@Order(5)
public void deleteLoanByIdTest(){
repo.delete(100);
assertEquals(false,repo.exists(100));
}
}