package com.zeta3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zeta3.model.User;
import com.zeta3.service.Myservice;

import java.util.Arrays;
import java.util.List;
//Service implementation class for Myservice interface
@Service
public class Myserviceimpl implements Myservice {
	@Autowired
	RestTemplate template;
    // Method to retrieve users from an external API
	public Object getUsers() {
		try {
			RestTemplate restTemplate = new RestTemplate();
            // Setting up HTTP headers for the request
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			ResponseEntity response = restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET, entity,
					Object.class);
			
			 Object data = (Object) response.getBody();
			System.out.println(data);
			return data;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
}
