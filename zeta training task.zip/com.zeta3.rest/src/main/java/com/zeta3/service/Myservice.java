package com.zeta3.service;

import java.util.List;
import java.util.Optional;

import com.zeta3.model.User;

//Service interface defining methods for User-related operations
public interface Myservice {
	public Object getUsers();

}
