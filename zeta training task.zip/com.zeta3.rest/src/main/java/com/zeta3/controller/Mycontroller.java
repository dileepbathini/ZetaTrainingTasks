package com.zeta3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zeta3.UserDetails;
import com.zeta3.model.Details;
import com.zeta3.model.User;
import com.zeta3.service.Myservice;
import com.zeta3.service.Myserviceimpl;

import java.util.List;

//RestController class for handling HTTP requests related to user details
@RestController
public class Mycontroller {
	@Autowired
	Myserviceimpl service;

	// Mapping for the endpoint "/users" with HTTP GET method
	// Consumes any media type and produces JSON
	@RequestMapping(value = "/users", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Object getAllUsers() {
		return service.getUsers();
	}

}
