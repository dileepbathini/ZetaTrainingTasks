package com.zeta3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

//Spring Boot application class for UserDetails
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class })
public class UserDetails {
	public static void main(String[] args) {
		SpringApplication.run(UserDetails.class, args);

	}

	// Bean definition for RestTemplate, used for making HTTP requests
	@Bean
	public RestTemplate template() {
		return new RestTemplate();
	}

}
