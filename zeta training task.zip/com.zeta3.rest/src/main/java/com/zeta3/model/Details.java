package com.zeta3.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

//Entity class representing the "Details" table in the database
@Entity
@Table(name = "Details")
public class Details {
	// Primary key field annotated with @Id
	@Id
	private Long id;
	// Fields representing columns in the "Details" table
	@Column
	private String email;
	@Column
	private String first_name;
	// Getter and Setter methods for each field

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	@Column
	private String last_name;
	@Column
	private String avatar;

}
